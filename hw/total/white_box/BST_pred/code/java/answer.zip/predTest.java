import static org.junit.Assert.*;

import org.junit.Test;

//import java.arith;

public class predTest { 
	Tree tree = new Tree();

	public predTest() {
		insert test = new insert();
		test.insert(tree, new BinNode(null, 44));
		test.insert(tree, new BinNode(null, 22));
		test.insert(tree, new BinNode(null, 66));
		test.insert(tree, new BinNode(null, 33));
		test.insert(tree, new BinNode(null, 55));
		test.insert(tree, new BinNode(null, 23));
		test.insert(tree, new BinNode(null, 34));
		test.insert(tree, new BinNode(null, 11));
		test.insert(tree, new BinNode(null, 12));
	}

    @Test
    public void test1(){ 
        pred test = new pred(); 
        String result = test.findPred(tree.root).toString();
        assertEquals("x.rChild",result,0); 
    } 

	@Test
    public void test2(){ 
        pred test = new pred(); 
        String result = test.findPred(tree.root.lc).toString();
        assertEquals("rChild",result,0); 
    } 

	@Test
    public void test3(){ 
        pred test = new pred(); 
        String result = test.findPred(tree.root.rc).toString();
        assertEquals("rChild",result,0); 
    } 

	@Test
    public void test4(){ 
        pred test = new pred(); 
        String result = test.findPred(tree.root.lc.rc).toString();
        assertEquals("u.rChild",result,0); 
    } 

	@Test
    public void test5(){ 
        pred test = new pred(); 
        String result = test.findPred(tree.root.rc.lc).toString();
        assertEquals("u.rChild",result,0); 
    } 

	@Test
    public void test6(){ 
        pred test = new pred(); 
        String result = test.findPred(tree.root.lc.rc.lc).toString();
        assertEquals("lChild",result,0); 
    } 

	@Test
    public void test7(){ 
        pred test = new pred(); 
        String result = test.findPred(tree.root.lc.rc.rc).toString();
        assertEquals("x.rChild",result,0); 
    } 

	@Test
    public void test8(){ 
        pred test = new pred(); 
        String result = test.findPred(tree.root.lc.lc).toString();
        assertEquals("x.rChild",result,0); 
    } 

	@Test
    public void test9(){ 
        pred test = new pred(); 
        String result = test.findPred(tree.root.lc.lc.rc).toString();
        assertEquals("x.rChild",result,0); 
    } 
}
