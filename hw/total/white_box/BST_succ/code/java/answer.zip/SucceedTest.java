import static org.junit.Assert.*;

import org.junit.Test;

//import java.arith;

public class SucceedTest { 
    BinNode root = new BinNode(null, 44);

	public SucceedTest() {
		root.set_lc(new BinNode(root, 22));
		root.set_rc(new BinNode(root, 66));
		root.getRc().set_lc(new BinNode(root.getRc(), 55));
		root.getRc().set_rc(new BinNode(root.getRc(), 77));
		root.getLc().set_lc(new BinNode(root.getLc(), 11));
		root.getLc().set_rc(new BinNode(root.getLc(), 33));
		root.getLc().getLc().set_rc(new BinNode(root.getLc().getLc(), 12));
		root.getLc().getRc().set_lc(new BinNode(root.getLc().getRc(), 23));
		root.getRc().getLc().set_lc(new BinNode(root.getRc().getLc(), 54));
		root.getRc().getRc().set_rc(new BinNode(root.getRc().getRc(), 78));
	}

	double getResult(BinNode a, BinNode b) {
		if (a == b)
			return 1.0;
		return -1.0;
	}

    @Test
    public void test1(){ 
        Succeed test = new Succeed(); 
        double result = getResult(test.getSucceed(root), root);
        assertEquals(1.0,result,0); 
    }

    @Test
    public void test2(){ 
        Succeed test = new Succeed(); 
        double result = getResult(test.getSucceed(root.getLc()), root);
        assertEquals(1.0,result,0); 
    }
    @Test
    public void test3(){ 
        Succeed test = new Succeed(); 
        double result = getResult(test.getSucceed(root.getRc()), root);
        assertEquals(1.0,result,0); 
    }
    @Test
    public void test4(){ 
        Succeed test = new Succeed(); 
        double result = getResult(test.getSucceed(root.getRc().getLc()), root);
        assertEquals(1.0,result,0); 
    }
    @Test
    public void test5(){ 
        Succeed test = new Succeed(); 
        double result = getResult(test.getSucceed(root.getLc().getRc()), root);
        assertEquals(1.0,result,0); 
    } 
    @Test
    public void test6(){ 
        Succeed test = new Succeed(); 
        double result = getResult(test.getSucceed(root.getRc().getRc()), root);
        assertEquals(1.0,result,0); 
    }
    @Test
    public void test7(){ 
        Succeed test = new Succeed(); 
        double result = getResult(test.getSucceed(root.getLc().getLc()), root);
        assertEquals(1.0,result,0); 
    } 
    @Test
    public void test8(){ 
        Succeed test = new Succeed(); 
        double result = getResult(test.getSucceed(root.getRc().getLc().getRc()), root);
        assertEquals(1.0,result,0); 
    }
    @Test
    public void test9(){ 
        Succeed test = new Succeed(); 
        double result = getResult(test.getSucceed(root.getLc().getRc().getLc()), root);
        assertEquals(1.0,result,0); 
    } 
    @Test
    public void test10(){ 
        Succeed test = new Succeed(); 
        double result = getResult(test.getSucceed(root.getRc().getRc().getLc()), root);
        assertEquals(1.0,result,0); 
    }
    @Test
    public void test11(){ 
        Succeed test = new Succeed(); 
        double result = getResult(test.getSucceed(root.getLc().getLc().getRc()), root);
        assertEquals(1.0,result,0); 
    } 

}


