import static org.junit.Assert.*;

import org.junit.Test;

//import java.arith;

public class SplayTest { 
    BinNode root = new BinNode(null, 44);

	public SplayTest() {
		root.set_lc(new BinNode(root, 22));
		root.set_rc(new BinNode(root, 66));
		root.getRc().set_lc(new BinNode(root.getRc(), 55));
		root.getRc().set_rc(new BinNode(root.getRc(), 77));
		root.getLc().set_lc(new BinNode(root.getLc(), 11));
		root.getLc().set_rc(new BinNode(root.getLc(), 33));
		root.getLc().getLc().set_rc(new BinNode(root.getLc().getLc(), 12));
		root.getLc().getRc().set_lc(new BinNode(root.getLc().getRc(), 23));
		root.getRc().getLc().set_lc(new BinNode(root.getRc().getLc(), 54));
		root.getRc().getRc().set_rc(new BinNode(root.getRc().getRc(), 78));
	}

    @Test
    public void test1(){ 
        Splay test = new Splay(); 
        String result = test.splay(root);
        assertEquals("root",result,0); 
    }

    @Test
    public void test2(){ 
        Splay test = new Splay(); 
        String result = test.splay(root.getLc());
        assertEquals("root",result,0); 
    }
    @Test
    public void test3(){ 
        Splay test = new Splay(); 
        String result = test.splay(root.getRc());
        assertEquals("root",result,0); 
    }
    @Test
    public void test4(){ 
        Splay test = new Splay(); 
        String result = test.splay(root.getRc().getLc());
        assertEquals("root",result,0); 
    }
    @Test
    public void test5(){ 
        Splay test = new Splay(); 
        String result = test.splay(root.getLc().getRc());
        assertEquals("root",result,0); 
    } 
    @Test
    public void test6(){ 
        Splay test = new Splay(); 
        String result = test.splay(root.getRc().getRc());
        assertEquals("root",result,0); 
    }
    @Test
    public void test7(){ 
        Splay test = new Splay(); 
        String result = test.splay(root.getLc().getLc());
        assertEquals("root",result,0); 
    } 
    @Test
    public void test8(){ 
        Splay test = new Splay(); 
        String result = test.splay(root.getRc().getLc().getRc());
        assertEquals("root",result,0); 
    }
    @Test
    public void test9(){ 
        Splay test = new Splay(); 
        String result = test.splay(root.getLc().getRc().getLc());
        assertEquals("root",result,0); 
    } 
    @Test
    public void test10(){ 
        Splay test = new Splay(); 
        String result = test.splay(root.getRc().getRc().getLc());
        assertEquals("root",result,0); 
    }
    @Test
    public void test11(){ 
        Splay test = new Splay(); 
        String result = test.splay(root.getLc().getLc().getRc());
        assertEquals("root",result,0); 
    } 

}


