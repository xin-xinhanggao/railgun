mv test_arith.java Test/test_arith.java
