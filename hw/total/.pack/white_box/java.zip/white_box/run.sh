javac Test/arith.java
javac Test/test_arith.java
javac Test/unitTest.java

java Test/unitTest
