def add(a, b):
    return a + b


def pow(a, b):
    return a ** b
