package Test;

public class arith { 
    public double add(double n1, double n2) { 
        return n1 + n2; 
    } 
}
