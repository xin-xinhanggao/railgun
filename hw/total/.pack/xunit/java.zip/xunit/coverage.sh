cp arithTest.java coverage/arithTest.java
cp arith.java coverage/arith.java
cd coverage
ant
