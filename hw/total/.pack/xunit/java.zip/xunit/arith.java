public class arith { 
    public double add(double n1, double n2) { 
	if (n1 > n2)
	        return n1 + n2; 
	else
		return n1 - n2;
    } 
}
