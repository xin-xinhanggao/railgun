import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class OperationTest { 
  @Test
  public void test_empty() { 
    double [][]matrix = new double[0][0];
    operation op = new operation();
    boolean temp = op.checkMatrix(matrix); 
    double result = 1;
    if (!temp) {
      result = -1;
    }
    assertEquals(-1,result,0); 
  }

  @Test
  public void test_column_different() { 
    double [][]matrix = new double[3][];
    matrix[0] = new double[5];
    matrix[1] = new double[4];
    matrix[2] = new double[5];
    operation op = new operation();
    boolean temp = op.checkMatrix(matrix); 
    double result = 1;
    if (!temp) {
      result = -1;
    }
    assertEquals(-1,result,0); 
  }  

  @Test
  public void test_legal() { 
    double [][]matrix = new double[3][];
    matrix[0] = new double[5];
    matrix[1] = new double[5];
    matrix[2] = new double[5];
    operation op = new operation();
    boolean temp = op.checkMatrix(matrix); 
    double result = 1;
    if (!temp) {
      result = -1;
    }
    assertEquals(1,result,0); 
  } 

  @Test
  public void test_illegal() { 
    double [][]matrix = new double[3][];
    matrix[0] = new double[5];
    matrix[1] = new double[4];
    matrix[2] = new double[5];
    operation op = new operation();
    double result = op.dot(matrix); 
    assertEquals(0,result,0); 
  } 

  @Test
  public void test_rec() { 
    double [][]matrix = new double[3][5];
    operation op = new operation();
    double result = op.dot(matrix); 
    assertEquals(0,result,0); 
  } 

  @Test
  public void test_one() { 
    double [][]matrix = new double[1][1];
    matrix[0][0] = 3;
    operation op = new operation();
    double result = op.dot(matrix); 
    assertEquals(3,result,0); 
  } 

  @Test
  public void test_high() { 
    double [][]matrix = new double[2][2];
    matrix[0][0] = matrix[0][1] = matrix[1][0] = 1;
    matrix[1][1] = 2;
    operation op = new operation();
    double result = op.dot(matrix); 
    assertEquals(1,result,0); 
  } 
}
