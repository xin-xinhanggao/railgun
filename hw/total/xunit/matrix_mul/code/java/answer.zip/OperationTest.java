import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class OperationTest { 
  @Test
  public void test_empty() { 
    double [][]matrix = new double[0][0];
    Operation op = new Operation();
    boolean temp = op.checkMatrix(matrix); 
    double result = 1;
    if (temp == null) {
      result = 0;
    }
    assertEquals(-1,result,0); 
  }

  @Test
  public void test_column_different() { 
    double [][]matrix = new double[3][];
    matrix[0] = new double[5];
    matrix[1] = new double[4];
    matrix[2] = new double[5];
    Operation op = new Operation();
    boolean temp = op.checkMatrix(matrix); 
    double result = 1;
    if (temp == null) {
      result = 0;
    }
    assertEquals(-1,result,0); 
  }  

  @Test
  public void test_legal() { 
    double [][]matrix = new double[3][];
    matrix[0] = new double[5];
    matrix[1] = new double[5];
    matrix[2] = new double[5];
    Operation op = new Operation();
    boolean temp = op.checkMatrix(matrix); 
    double result = 1;
    if (temp == null) {
      result = 0;
    }
    assertEquals(1,result,0); 
  } 

  @Test
  public void test_legal_mul_illegal() { 
    double [][]matrix1 = new double[3][5];
    double [][]matrix2 = new double[3][];
    matrix2[0] = new double[5];
    matrix2[1] = new double[4];
    matrix2[2] = new double[5];
    Operation op = new Operation();
    double[][] temp = op.multiply(matrix1, matrix2); 
    double result = 1;
    if (temp == null) {
      result = 0;
    }
    assertEquals(0,result,0); 
  } 

  @Test
  public void test_illegal_mul_legal() { 
    double [][]matrix1 = new double[3][5];
    double [][]matrix2 = new double[3][];
    matrix2[0] = new double[5];
    matrix2[1] = new double[4];
    matrix2[2] = new double[5];
    Operation op = new Operation();
    double[][] temp = op.multiply(matrix2, matrix1); 
    double result = 1;
    if (temp == null) {
      result = 0;
    }
    assertEquals(0,result,0); 
  } 

  @Test
  public void test_illegal_mul_illegal() { 
    double [][]matrix2 = new double[3][];
    matrix2[0] = new double[5];
    matrix2[1] = new double[4];
    matrix2[2] = new double[5];
    Operation op = new Operation();
    double[][] temp = op.multiply(matrix2, matrix2); 
    double result = 1;
    if (temp == null) {
      result = 0;
    }
    assertEquals(0,result,0); 
  } 

  @Test
  public void test_scale_error() { 
    double [][]matrix1 = new double[3][5];
    double [][]matrix2 = new double[4][5];
    Operation op = new Operation();
    double[][] temp = op.multiply(matrix1, matrix2); 
    double result = 1;
    if (temp == null) {
      result = 0;
    }
    assertEquals(0,result,0); 
  } 

  @Test
  public void test_legal_mul_legal() { 
    double [][]matrix1 = new double[3][5];
    double [][]matrix2 = new double[5][4];
    Operation op = new Operation();
    double[][] temp = op.multiply(matrix1, matrix2); 
    double result = 1;
    if (temp == null) {
      result = 0;
    }
    assertEquals(1,result,0); 
  } 
}
