import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class MinmaxTest { 
  @Test
  public void test_abc() { 
    Minmax test = new Minmax(); 
    double result = test.get_max(1,2,3); 
    assertEquals(3,result,0); 
  } 

  @Test
  public void test_acb() { 
    Minmax test = new Minmax(); 
    double result = test.get_max(1,3,2); 
    assertEquals(3,result,0); 
  } 

  @Test
  public void test_bac() { 
    Minmax test = new Minmax(); 
    double result = test.get_max(-1,-2,1); 
    assertEquals(1,result,0); 
  } 

  @Test
  public void test_bca() { 
    Minmax test = new Minmax(); 
    double result = test.get_max(2,-3,-1); 
    assertEquals(2,result,0); 
  } 

  @Test
  public void test_cab() { 
    Minmax test = new Minmax(); 
    double result = test.get_max(-2,2,-3); 
    assertEquals(2,result,0); 
  } 

  @Test
  public void test_cba() { 
    Minmax test = new Minmax(); 
    double result = test.get_max(2,-2,-3); 
    assertEquals(2,result,0); 
  } 
}


