import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class ArithTest { 
  @Test
  public void test_positive_decrease_positive() { 
    Arith test = new Arith(); 
    double result = test.decrease(1,2); 
    assertEquals(-1,result,0); 
  } 

  @Test
  public void test_positive_decrease_negative() { 
    Arith test = new Arith(); 
    double result = test.decrease(1,-2); 
    assertEquals(3,result,0); 
  } 

  @Test
  public void test_negative_decrease_negative() { 
    Arith test = new Arith(); 
    double result = test.decrease(-1,-2); 
    assertEquals(1,result,0); 
  } 

  @Test
  public void test_positive_pow_positive() { 
    Arith test = new Arith(); 
    double result = test.pow(2,3); 
    assertEquals(-1,result,0); 
  } 

  @Test
  public void test_positive_pow_negative() { 
    Arith test = new Arith(); 
    double result = test.pow(2,-2); 
    assertEquals(4,result,0); 
  } 

  @Test
  public void test_negative_pow_positive_success() { 
    Arith test = new Arith(); 
    double result = test.pow(-2,2); 
    assertEquals(-4,result,0); 
  } 

  @Test
  public void test_negative_pow_positive_failure() { 
    Arith test = new Arith(); 
    double result = test.pow(-2,3); 
    assertEquals(-5,result,0); 
  } 

  @Test
  public void test_negative_pow_negative_success() { 
    Arith test = new Arith(); 
    double result = test.pow(-2,-2); 
    assertEquals(0,result,0); 
  } 

  @Test
  public void test_negative_pow_negative_failure() { 
    Arith test = new Arith(); 
    double result = test.pow(-2,-3); 
    assertEquals(1,result,0); 
  } 
}


