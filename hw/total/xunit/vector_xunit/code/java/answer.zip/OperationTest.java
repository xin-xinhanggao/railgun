import org.junit.Test;

public class OperationTest {
  @Test
  public void test_zero_cross_zero() {
    Operation test = new Operation();
    test.cross(new Vec(), new Vec());
  }

  @Test
  public void test_zero_cross_normal() {
    Operation test = new Operation();
    test.cross(new Vec(), new Vec(1, 0, 0));
  }

  @Test
  public void test_p1_cross_p2() {
    Operation test = new Operation();
    test.cross(new Vec(-1, 0, 0), new Vec(1, 0, 0));
  }

  @Test
  public void test_n1_cross_n2() {
    Operation test = new Operation();
    test.cross(new Vec(1, 1, 0), new Vec(1, 0, 0));
  }

  @Test
  public void test_zero_dot_zero() {
    Operation test = new Operation();
    test.dot(new Vec(), new Vec());
  }

  @Test
  public void test_zero_dot_n1() {
    Operation test = new Operation();
    test.dot(new Vec(), new Vec(1, 0, 0));
  }

  @Test
  public void test_v1_dot_v2() {
    Operation test = new Operation();
    test.dot(new Vec(0, 1, 0), new Vec(1, 0, 0));
  }

  @Test
  public void test_n1_dot_n2() {
    Operation test = new Operation();
    test.dot(new Vec(1, 1, 0), new Vec(1, 0, 0));
  }
}
