import org.junit.Test;

public class GetVerticalTest {
  @Test
  public void test_z_z() {
    GetVertical test = new GetVertical();
    test.getVertical(new Vec(), new Vec());
  }

  @Test
  public void test_z_n() {
    GetVertical test = new GetVertical();
    test.getVertical(new Vec(), new Vec(1, 0, 0));
  }

  @Test
  public void test_p_p() {
    GetVertical test = new GetVertical();
    test.getVertical(new Vec(-1, 0, 0), new Vec(1, 0, 0));
  }

  @Test
  public void test_n_n() {
    GetVertical test = new GetVertical();
    test.getVertical(new Vec(1, 1, 0), new Vec(1, 0, 0));
  }
}
