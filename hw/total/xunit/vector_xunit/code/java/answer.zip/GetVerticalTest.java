import static org.junit.Assert.*;

import org.junit.Test;

public class GetVerticalTest {
	public double isEqual(Vec v1, Vec v2) {
		if (new Vec(v1.x - v2.x, v1.y - v2.y, v1.z - v2.z).isZero())
			return 1.0;
		else
			return -1.0;
	}

	@Test
	public void test_z_z() {
		GetVertical test = new GetVertical();
		test.getVertical(new Vec(), new Vec());
	}

	@Test
	public void test_z_n() {
		GetVertical test = new GetVertical();
		test.getVertical(new Vec(), new Vec(1, 0, 0));
	}

	@Test
	public void test_p_p() {
		GetVertical test = new GetVertical();
		test.getVertical(new Vec(-1, 0, 0), new Vec(1, 0, 0));
	}

	@Test
	public void test_n_n() {
		GetVertical test = new GetVertical();
		test.getVertical(new Vec(1, 1, 0), new Vec(1, 0, 0));
	}
}
