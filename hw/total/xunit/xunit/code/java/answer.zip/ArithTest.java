import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class ArithTest { 
  @Test
  public void test_positive_add_positive() { 
    Arith test = new Arith(); 
    double result = test.add(1,2); 
    assertEquals(3,result,0); 
  } 

  @Test
  public void test_positive_add_negative() { 
    Arith test = new Arith(); 
    double result = test.add(1,-2); 
    assertEquals(-1,result,0); 
  } 

  @Test
  public void test_negative_add_negative() { 
    Arith test = new Arith(); 
    double result = test.add(-1,-2); 
    assertEquals(-3,result,0); 
  } 

  @Test
  public void test_positive_pow_positive() { 
    Arith test = new Arith(); 
    double result = test.pow(2,3); 
    assertEquals(8,result,0); 
  } 

  @Test
  public void test_positive_pow_negative() { 
    Arith test = new Arith(); 
    double result = test.pow(2,-2); 
    assertEquals(0.25,result,0); 
  } 

  @Test
  public void test_negative_pow_positive_success() { 
    Arith test = new Arith(); 
    double result = test.pow(-2,2); 
    assertEquals(4,result,0); 
  } 

  @Test
  public void test_negative_pow_positive_failure() { 
    Arith test = new Arith(); 
    double result = test.pow(-2,3); 
    assertEquals(4,result,0); 
  } 

  @Test
  public void test_negative_pow_negative_success() { 
    Arith test = new Arith(); 
    double result = test.pow(-2,-2); 
    assertEquals(0.25,result,0); 
  } 

  @Test
  public void test_negative_pow_negative_failure() { 
    Arith test = new Arith(); 
    double result = test.pow(-2,-3); 
    assertEquals(0.125,result,0); 
  } 
}


